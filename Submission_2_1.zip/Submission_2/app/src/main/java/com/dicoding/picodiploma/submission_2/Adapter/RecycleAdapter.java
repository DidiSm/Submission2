package com.dicoding.picodiploma.submission_2.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.dicoding.picodiploma.submission_2.Data.Movie;
import com.dicoding.picodiploma.submission_2.R;

import java.util.ArrayList;

public class RecycleAdapter extends RecyclerView.Adapter<RecycleAdapter.RecycleViewHolder> {
    private ArrayList<Movie> listMovie;
    private final Context context;
    private OnItemClickCallback onItemClickCallback;

    public void setMovies(ArrayList<Movie> movies) {
        this.listMovie = movies;
    }

    public void setOnItemClickCallback(OnItemClickCallback onItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback;
    }

    public RecycleAdapter(ArrayList<Movie> list, Context context) {
        this.listMovie = list;
        this.context = context;
    }

    @NonNull
    @Override
    public RecycleViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycle_item, parent, false);
        return new RecycleViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final RecycleViewHolder holder, int position) {
        final Movie movie = listMovie.get(position);
        Glide.with(holder.itemView.getContext())
                .load(movie.getPhoto())
                .apply(new RequestOptions().override(55,55))
                .into(holder.rPhoto);

        holder.rPhoto.setImageResource(listMovie.get(position).getPhoto());
        holder.rJudul.setText(listMovie.get(position).getJudul());
        holder.rDesc.setText(listMovie.get(position).getDesc());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onItemClickCallback.onItemClicked(listMovie.get(holder.getAdapterPosition()));

                Movie movie1 = new Movie();
                movie1.setPhoto(movie.getPhoto());
                movie1.setJudul(movie.getJudul());
                movie1.setDesc(movie.getDesc());
                movie1.setTglMovie(movie.getTglMovie());
                movie1.setCrewMovie(movie.getCrewMovie());
                movie1.setCrewDetailMovie(movie.getCrewDetailMovie());
            }
        });

    }

    @Override
    public int getItemCount() {
        return listMovie.size();
    }


    public class RecycleViewHolder extends RecyclerView.ViewHolder {
        public TextView rJudul,rDesc;
        ImageView rPhoto;

        public RecycleViewHolder(@NonNull View itemView) {
            super(itemView);
            rPhoto = itemView.findViewById(R.id.recycle_photo);
            rJudul = itemView.findViewById(R.id.recycle_title);
            rDesc = itemView.findViewById(R.id.recycle_desc);
        }
    }

    public interface OnItemClickCallback{
        void onItemClicked (Movie movie);
    }
}
