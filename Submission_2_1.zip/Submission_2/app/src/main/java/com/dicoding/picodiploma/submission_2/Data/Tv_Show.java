package com.dicoding.picodiploma.submission_2.Data;

import android.os.Parcel;
import android.os.Parcelable;

public class Tv_Show implements Parcelable {

    private String tvJudul, tvRelease, tvDuration, tvDesc;
    private int photo;

    public String getTvJudul() {
        return tvJudul;
    }

    public void setTvJudul(String tvJudul) {
        this.tvJudul = tvJudul;
    }

    public String getTvRelease() {
        return tvRelease;
    }

    public void setTvRelease(String tvRelease) {
        this.tvRelease = tvRelease;
    }

    public String getTvDuration() {
        return tvDuration;
    }

    public void setTvDuration(String tvDuration) {
        this.tvDuration = tvDuration;
    }

    public String getTvDesc() {
        return tvDesc;
    }

    public void setTvDesc(String tvDesc) {
        this.tvDesc = tvDesc;
    }

    public int getPhoto() {
        return photo;
    }

    public void setPhoto(int photo) {
        this.photo = photo;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(tvJudul);
        parcel.writeString(tvRelease);
        parcel.writeString(tvDuration);
        parcel.writeString(tvDesc);
        parcel.writeInt(photo);
    }

    private Tv_Show(Parcel in) {
        tvJudul = in.readString();
        tvRelease = in.readString();
        tvDuration = in.readString();
        tvDesc = in.readString();
        photo = in.readInt();
    }

    public static final Creator<Tv_Show> CREATOR = new Creator<Tv_Show>() {
        @Override
        public Tv_Show createFromParcel(Parcel in) {
            return new Tv_Show(in);
        }

        @Override
        public Tv_Show[] newArray(int size) {
            return new Tv_Show[size];
        }
    };
}
