package com.dicoding.picodiploma.submission_2.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.dicoding.picodiploma.submission_2.Data.Movie;
import com.dicoding.picodiploma.submission_2.R;

public class DetailActivity extends AppCompatActivity {
    private TextView mJudul,mTglMovie,mDesc,mCrew,mCrewDetail;
    ImageView imgPhoto;
    public static final String EXTRA_MOVIE = "extra_movie";

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //Intent intent = getIntent();
        //Movie movie = intent.getParcelableExtra("EXTRA_MOVIE");
        //String movieJudul = movie.getJudul();
        //String movieDesc = movie.getDesc();
        //String movieTgl = movie.getTglMovie();
        //String movieCrew = movie.getCrewMovie();
        //String movieCrewDetail = movie.getCrewDetailMovie();
        imgPhoto = findViewById(R.id.img_photo);
        mJudul = findViewById(R.id.txt_title);
        mTglMovie = findViewById(R.id.txt_tgl);
        mDesc= findViewById(R.id.txt_desc);

        Movie movie = getIntent().getParcelableExtra(EXTRA_MOVIE);
        assert movie !=null;
        mJudul.setText(movie.getJudul());
        mTglMovie.setText(movie.getTglMovie());
        mDesc.setText(movie.getDesc());
        int Photo = movie.getPhoto();
        imgPhoto.setImageResource(Photo);

        //getSupportActionBar().setTitle(movieJudul);

        //ImageView imageView = findViewById(R.id.img_photo);
        //Glide.with(this)
        //        .load(movie.getPhoto())
        //        .into(imageView);

        //mJudul = findViewById(R.id.txt_title);
        //mJudul.setText(movieJudul);
        //mDesc = findViewById(R.id.txt_desc);
        //mDesc.setText(movieDesc);
        //mTglMovie = findViewById(R.id.txt_tgl);
        //mTglMovie.setText(movieTgl);
        //mCrew =findViewById(R.id.crew_detail);
        //mCrew.setText(movieCrew);
        //mCrewDetail =findViewById(R.id.position_detail);
        //mCrewDetail.setText(movieCrewDetail);
    }
}
