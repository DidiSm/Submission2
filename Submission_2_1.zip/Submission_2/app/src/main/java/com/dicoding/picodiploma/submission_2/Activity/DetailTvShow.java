package com.dicoding.picodiploma.submission_2.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.dicoding.picodiploma.submission_2.Data.Tv_Show;
import com.dicoding.picodiploma.submission_2.R;

public class DetailTvShow extends AppCompatActivity {

    private TextView tvJudul,tvRelease,tvDuration, tvDesc;
    public static final String EXTRA_TV = "extra_tv";

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_tv_show);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Intent intent = getIntent();
        Tv_Show tv_show = intent.getParcelableExtra("EXTRA_TV");
        String tvsJudul = tv_show.getTvJudul();
        String tvsRelease = tv_show.getTvRelease();
        String tvsDuration = tv_show.getTvDuration();
        String tvsDesc = tv_show.getTvDesc();

        getSupportActionBar().setTitle(tvsJudul);

        ImageView imageView = findViewById(R.id.tvshow_photo);
        Glide.with(this)
                .load(tv_show.getPhoto())
                .into(imageView);

        tvJudul = findViewById(R.id.tvshow_judul);
        tvJudul.setText(tvsJudul);
        tvRelease = findViewById(R.id.tvshow_release);
        tvRelease.setText(tvsRelease);
        tvDuration = findViewById(R.id.tvshow_duration);
        tvDuration.setText(tvsDuration );
        tvDesc =findViewById(R.id.tvshow_desc);
        tvDesc.setText(tvsDesc);
    }
}
